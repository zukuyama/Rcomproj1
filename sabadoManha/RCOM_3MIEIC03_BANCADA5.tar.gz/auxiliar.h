//
//  auxiliar.h
//  RCOM_PROJ1
//
//  Created by GROUP_.
//

#ifndef __RCOM_PROJ1__auxiliar__
#define __RCOM_PROJ1__auxiliar__

#include "include.h"

int    print(char * string);
char * itoa(int value, char* result, int base);

#endif /* defined(__RCOM_PROJ1__auxiliar__) */
