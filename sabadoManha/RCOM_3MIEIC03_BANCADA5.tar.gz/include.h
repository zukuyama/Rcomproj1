//
//  include.h
//  RCOM_PROJ1
//
//  Created by GROUP_.
//

#ifndef RCOM_PROJ1_include_h
#define RCOM_PROJ1_include_h

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

#include <math.h>

#endif
