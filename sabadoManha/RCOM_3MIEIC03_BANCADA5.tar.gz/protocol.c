//
//  protocol.c
//  RCOM_PROJ1
//
//  Created by GROUP_.
//

#include "protocol.h"

void init_SET_and_UA()
{
    set[0] = F;
    set[1] = A;
    set[2] = C_SET;
    set[3] = (set[1] ^ set[2]);
    set[4] = F;
    
    ua[0] = F;
    ua[1] = A;
    ua[2] = C_UA;
    ua[3] = (ua[1] ^ ua[2]);
    ua[4] = F;
}