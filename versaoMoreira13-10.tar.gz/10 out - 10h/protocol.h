#ifndef PROTOCOL_H
#define PROTOCOL_H

#define F 0x7e
#define A 0x03
#define C 0x03

typedef unsigned char Byte;

Byte set[5];
Byte ua[5];

void definirSetUa()
{
	set[0] = F;
	set[1] = A;
	set[2] = C;
	set[3] = set[1] ^ set[2];
	set[4] = F;
	
	unsigned int i;
	for (i = 0; i < 5; i++)
		ua[i] = set[i];
}

#endif
