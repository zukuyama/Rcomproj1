/*Non-Canonical Input Processing*/
/*********************************************************
*	COMPILAR: 	gcc s.c -o s
* COMPILAR AMBOS: 	gcc r.c -o r | gcc s.c -o s
*	EXECUTAR: 	./s /dev/ttySx , x = {0, 4}
*																				x = 4: servidor
*																				x = 0: cliente
* ------------------------------------------------------
*										set | tentativa1
*		emissor(programa) --------------> receptor
*
*										set | tentativa2
*		emissor(programa) --------------> receptor
*
*							(caso sucesso)
*
*														ua
*		emissor(programa) <-------------- receptor
*********************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

#include "protocol.h"
#include "layers.h"

#define BAUDRATE B9600
#define MODEMDEVICE "/dev/ttyS1"
#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1

/************************************************
*							GLOBAL VARIABLES
************************************************/

/*
	is a qualifier that is applied to a variable when it is declared.
	It tells the compiler that the value of the variable may
	change at any time-without any action
	being taken by the code the compiler finds nearby. 
	The implications of this are quite serious.
*/
volatile int STOP=FALSE;
volatile int estadoSET = FALSE;
volatile int estadoUA = FALSE;

static int flag=1, conta=0;
unsigned char buf[255];
struct termios oldtio, newtio;
int fd; // descritor de ficheiro

/************************************************
*							GLOBAL FUNCTIONS
************************************************/

void atende() // atende alarme
{
	//texto("Chamada atendida.\n");
	//getchar();
	flag = 1;
	
	//if (!(estadoSET == TRUE && estadoUA == TRUE))
	//{
	if (conta < 2)
	{
		estadoSET = FALSE;
		estadoUA = FALSE;
		
		if (STOP == TRUE)
		{
			flag = 0;
			printf("Message sent without problem\n");
		}
		else
		{
			conta++;
			STOP = FALSE;
			printf("Re-Sending SET... by the %d time.\n", conta);
			
		}
		
	}
	else
	{
		flag = 0;
		STOP = TRUE;
		printf("No sending alarms anymore. Number of times sent: %d\n", conta);
		conta++;
	}
	//}
	//getchar();
}

/*
    	Open serial port device for reading and writing and not as controlling tty
    	because we don't want to get killed if linenoise sends CTRL-C.
*/
void definirSettings(int argc, char** argv)
{
    fd = open(argv[1], O_RDWR | O_NOCTTY ); // fd = number of file descriptor
    if (fd < 0)
    {
    	perror(argv[1]);
    	exit(-1);
    }

    if ( tcgetattr(fd,&oldtio) == -1) { // save current port settings
      perror("tcgetattr");
      exit(-1);
    }

    bzero(&newtio, sizeof(newtio));
    newtio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
    newtio.c_iflag = IGNPAR;
    newtio.c_oflag = 0;

    /* set input mode (non-canonical, no echo,...) */
    newtio.c_lflag = 0;

    newtio.c_cc[VTIME]    = 0;   /* inter-character timer unused */
    newtio.c_cc[VMIN]     = 5;   /* blocking read until 5 chars received */
    
  /* 
    VTIME e VMIN devem ser alterados de forma a proteger com um temporizador a 
    leitura do(s) pr�ximo(s) caracter(es)
  */

    tcflush(fd, TCIOFLUSH);
    if ( tcsetattr(fd,TCSANOW,&newtio) == -1) {
      perror("tcsetattr");
      exit(-1);
    }
}

void redefinirSettings()
{
	if ( tcsetattr(fd,TCSANOW,&oldtio) == -1)
	{
      perror("tcsetattr");
      exit(-1);
   }
}

/************************************************
*								MAIN FUNCTION
************************************************/
int main(int argc, char** argv)
{
	/*
			Verify if arguments are valid:
			- "/dev/ttyS0" is the server (computer on the right)
			- "/dev/ttyS4" is the client (computer on the left)
	*/
	if ( (argc < 2) || ((strcmp("/dev/ttyS0", argv[1])!=0) && (strcmp("/dev/ttyS4", argv[1])!=0) ))
	{
		printf("Usage:\tnserial SerialPort\n\tex: nserial /dev/ttyS4\n");
		exit(1);
	}

	/*
			ATRIBUICAO DE SINAIS DEVE SER FEITA AO INICIO DE UM MAIN
	*/
	(void) signal(SIGALRM, atende);  // instala rotina que atende interrupcao

	/*
			VARIAVEIS LOCAIS	
	*/
	int c, res;
	int i, sum = 0, speed = 0;

	/*
			INICIO DO PROGRAMA	
	*/
	system("clear");
	definirSettings(argc, argv); //atribuir o descritor do ficheiro de serial port
	definirSetUa(); //definir SET e UA

     //res = write(fd,set,5);
     // enviar set
     printf("Sending SET...\n");
     while(!STOP)
     {
       if(flag) // flag = 1 quando precisa de renviar a trama
       {
          flag=0;
          alarm(3);                 // activa alarme de 3s
     	  	 res = write(fd,set,5);
       }
       
       if (estadoSET == TRUE) // servidor recebeu / cliente enviou o SET
       {
       	  // receber ua
       	  printf("SET sent... Receiving UA...\n");
       	  
       	  while (!STOP)
       	  {
       	  		res = read(fd, buf, 255);
       	  
       	  		if (strcmp(buf, ua) == 0)
       	  		{
       	  			alarm(0);
       	  			
       	  	  		printf("UA received...\n");
       	  	  		estadoUA = TRUE;
       	  	  		STOP = TRUE;
       	  	   
       	  	   	redefinirSettings();
    					close(fd);
       	  	   	return(0);
       	  		}
       	  }
       	  
       	  // recomecar a enviar set
       	  printf("Re-Sending SET...\n");
       }
     }
	  
	  if (conta == 3) // nao conseguiu nem receber nem enviar nada a tempo
	  {
	  		return(-1);
	  }

    redefinirSettings();
    close(fd);
    return(-1);
}

